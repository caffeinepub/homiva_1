# 🏠 HOMIVA Flutter App
### *Care That Comes Home*

A professional cross-platform mobile application built with **Flutter** for both **Android** and **iOS**.

---

## 📱 App Screens

| Screen | Description |
|--------|-------------|
| **Home** | Hero section, problem statement, service cards, USPs, target market |
| **Safety** | 6-layer verification system, trust badges, USP grid |
| **Financials** | Revenue bar chart, sector breakdown, investment details, investor ask |
| **About** | Brand story, mission, marketing strategy, team profiles |

Each service card opens a full **Service Detail Screen** with features, pricing, and booking CTA.

---

## 🚀 How to Run

### Prerequisites
Install Flutter SDK from https://flutter.dev/docs/get-started/install

```bash
# Verify installation
flutter doctor
```

### 1. Clone / Open the project
```bash
cd homiva_flutter
```

### 2. Get dependencies
```bash
flutter pub get
```

### 3. Run on Android
```bash
# Connect Android device or start emulator
flutter run
```

### 4. Run on iOS (macOS only)
```bash
# Install pods first
cd ios && pod install && cd ..
flutter run
```

### 5. Build release APK (Android)
```bash
flutter build apk --release
# Output: build/app/outputs/flutter-apk/app-release.apk
```

### 6. Build release IPA (iOS)
```bash
flutter build ipa --release
# Requires Apple Developer account
```

---

## 📦 Dependencies

| Package | Purpose |
|---------|---------|
| `google_fonts` | DM Sans + DM Serif Display typography |
| `fl_chart` | Revenue bar chart in Financials screen |
| `flutter_animate` | Smooth animations |
| `provider` | State management |
| `shared_preferences` | Local storage |
| `url_launcher` | External links |
| `carousel_slider` | Onboarding / feature carousel |

---

## 🎨 Design System

**Colors:**
- Cream background: `#FAF8F5`
- Coral accent: `#E05A47`
- Charcoal text: `#2A2724`
- Taupe secondary: `#8A7F74`
- Warm accent: `#F5EDE0`

**Typography:**
- Headings: DM Serif Display (Google Fonts)
- Body: DM Sans (Google Fonts)

---

## 🏗️ Project Structure

```
lib/
├── main.dart                    # Entry point + bottom nav shell
├── theme/
│   └── app_theme.dart           # Colors, typography, ThemeData
├── models/
│   └── data.dart                # All business data & models
├── widgets/
│   └── common_widgets.dart      # Reusable UI components
└── screens/
    ├── home_screen.dart         # Home tab
    ├── service_detail_screen.dart # Service deep-dive
    ├── safety_screen.dart       # Trust & Safety tab
    ├── financials_screen.dart   # Financials tab
    └── about_screen.dart        # About & Team tab
```

---

## 📊 Business Data (from Report)

- **4 core services:** Elderly Care, Babysitting, Household Help, Pet Care
- **Revenue model:** 25% platform commission
- **Year-1 Revenue target:** ₹51 Lakhs
- **Initial investment:** ₹17 Lakhs
- **Total Year-1 capital needed:** ≈ ₹1 Crore
- **Investor ask:** ₹1.5 Crore seed
- **Break-even:** 18–24 months

---

## 👥 Team — Group 4

- Sanchita Dey
- Subhangi Saha
- Simran Prasad
- Kusum Sharma
- Rahul Roy
- Purnima Sinha
- Subhajit Bhowmick

---

## 📋 Minimum Requirements

| Platform | Requirement |
|----------|------------|
| Android  | API 21+ (Android 5.0 Lollipop) |
| iOS      | iOS 12.0+ |
| Flutter  | 3.0.0+ |
| Dart     | 3.0.0+ |

---

*Marketing Management Assignment — Create, Brand & Launch Report*
