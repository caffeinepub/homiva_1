// ── Service Model ─────────────────────────────────────────────────────────────
class ServiceModel {
  final String id;
  final String emoji;
  final String title;
  final String subtitle;
  final String description;
  final List<String> features;
  final List<String> tags;
  final String avgPrice;
  final String commission;
  final String monthlyRevenue;
  final String revenueShare;
  final int colorIndex;

  const ServiceModel({
    required this.id,
    required this.emoji,
    required this.title,
    required this.subtitle,
    required this.description,
    required this.features,
    required this.tags,
    required this.avgPrice,
    required this.commission,
    required this.monthlyRevenue,
    required this.revenueShare,
    required this.colorIndex,
  });
}

final List<ServiceModel> homIvaServices = [
  ServiceModel(
    id: 'elderly',
    emoji: '🏥',
    title: 'Elderly Care',
    subtitle: 'Nursing & Companionship',
    description:
        'Professional care for senior citizens by retired nurses and army personnel. '
        'We provide both medical support and emotional companionship, '
        'reducing dependence on family members while ensuring safety and discipline.',
    features: [
      'Blood pressure & sugar monitoring',
      'Medication management & first aid',
      'Post-hospitalization recovery care',
      'Hospital & pharmacy escort',
      'Morning / evening walk companion',
      'Emotional companionship support',
    ],
    tags: ['Nursing Care', 'Companionship', 'Medical Support', 'Elder Safety'],
    avgPrice: '₹700',
    commission: '25%',
    monthlyRevenue: '₹68,250',
    revenueShare: '36%',
    colorIndex: 0,
  ),
  ServiceModel(
    id: 'babysitting',
    emoji: '👶',
    title: 'Babysitting',
    subtitle: 'Trained Female Caregivers',
    description:
        'Reliable and planned childcare from trained female caregivers with 2+ years '
        'of experience, partnered with women SHGs and NGOs. Flexible 3, 6, and 9-month '
        'subscription packages designed for working parents.',
    features: [
      'Child supervision at home',
      'Educational play & creative tasks',
      'Basic learning support',
      '3 / 6 / 9 month packages',
      'Minimum 2 years experience',
      'All-female caregiver staff',
    ],
    tags: ['Female Staff Only', 'Subscription Plans', 'Educational Play'],
    avgPrice: '₹500',
    commission: '25%',
    monthlyRevenue: '₹48,750',
    revenueShare: '26%',
    colorIndex: 1,
  ),
  ServiceModel(
    id: 'household',
    emoji: '🏠',
    title: 'Household Help',
    subtitle: 'On-Demand Daily Chores',
    description:
        'Book household help only when you need it — more flexible and affordable '
        'than hiring a full-time maid. Covers everything from daily cleaning to '
        'event support for birthday parties and family gatherings.',
    features: [
      'Room cleaning & sweeping',
      'Washing clothes & utensils',
      'Vegetable cutting & meal prep',
      'Small daily chore support',
      'Birthday & event helpers',
      'No long-term commitment needed',
    ],
    tags: ['On-Demand', 'Flexible Booking', 'Event Support', 'Affordable'],
    avgPrice: '₹350',
    commission: '25%',
    monthlyRevenue: '₹45,500',
    revenueShare: '24%',
    colorIndex: 2,
  ),
  ServiceModel(
    id: 'petcare',
    emoji: '🐾',
    title: 'Pet Care',
    subtitle: 'Verified Pet Professionals',
    description:
        'Professional pet care through collaboration with verified local pet shops '
        'and pet care centres. Your pets receive experienced, trusted attention '
        'so you can travel or work without worry.',
    features: [
      'Pet feeding as per instructions',
      'Daily walking & exercise',
      'Short-duration pet sitting',
      'Basic hygiene assistance',
      'Local pet shop partnerships',
      'Experienced animal handlers',
    ],
    tags: ['Pet Walking', 'Feeding', 'Pet Sitting', 'Shop Partnerships'],
    avgPrice: '₹400',
    commission: '25%',
    monthlyRevenue: '₹26,000',
    revenueShare: '14%',
    colorIndex: 3,
  ),
];

// ── USP Model ─────────────────────────────────────────────────────────────────
class UspModel {
  final String emoji;
  final String title;
  final String description;
  const UspModel({required this.emoji, required this.title, required this.description});
}

final List<UspModel> homIvaUsps = [
  UspModel(emoji: '🪪', title: 'KYC Verified', description: 'Aadhaar & PAN authentication for every partner'),
  UspModel(emoji: '👮', title: 'Police Cleared', description: 'Criminal background check before onboarding'),
  UspModel(emoji: '📍', title: 'GPS Tracking', description: 'Real-time location throughout the job'),
  UspModel(emoji: '🔐', title: 'Dual OTP', description: 'Start & end OTP for tamper-proof service'),
  UspModel(emoji: '⚡', title: '15–20 Min', description: 'Hyper-local 2 km radius response'),
  UspModel(emoji: '🔁', title: 'Rebook Favourite', description: 'Request your preferred worker again'),
];

// ── Safety Steps ──────────────────────────────────────────────────────────────
class SafetyStep {
  final int step;
  final String title;
  final String description;
  final String emoji;
  const SafetyStep({required this.step, required this.title, required this.description, required this.emoji});
}

final List<SafetyStep> safetySteps = [
  SafetyStep(step: 1, emoji: '🪪', title: 'KYC Verification', description: 'Aadhaar/PAN submission and identity confirmation before joining the platform.'),
  SafetyStep(step: 2, emoji: '👮', title: 'Police Verification', description: 'Criminal background check ensuring workers are safe for family homes.'),
  SafetyStep(step: 3, emoji: '📚', title: 'Training & Screening', description: 'Category-specific training in elder care, babysitting, household help, or pet care.'),
  SafetyStep(step: 4, emoji: '🎓', title: 'Platform Certification', description: 'Official HOMIVA certificate issued post-training for professional credibility.'),
  SafetyStep(step: 5, emoji: '🔐', title: 'Dual OTP Auth', description: 'Start & end OTPs ensure every service begins and ends with customer confirmation.'),
  SafetyStep(step: 6, emoji: '📍', title: 'GPS Tracking', description: 'Live location tracking of service partner throughout the booking duration.'),
];

// ── Team Members ──────────────────────────────────────────────────────────────
class TeamMember {
  final String name;
  final String emoji;
  const TeamMember({required this.name, required this.emoji});
}

final List<TeamMember> teamMembers = [
  TeamMember(name: 'Sanchita Dey', emoji: '👩'),
  TeamMember(name: 'Subhangi Saha', emoji: '👩'),
  TeamMember(name: 'Simran Prasad', emoji: '👩'),
  TeamMember(name: 'Kusum Sharma', emoji: '👩'),
  TeamMember(name: 'Rahul Roy', emoji: '👨'),
  TeamMember(name: 'Purnima Sinha', emoji: '👩'),
  TeamMember(name: 'Subhajit Bhowmick', emoji: '👨'),
];

// ── Financial Data ────────────────────────────────────────────────────────────
class MonthRevenue {
  final String month;
  final int bookings;
  final double revenueL; // in Lakhs
  const MonthRevenue({required this.month, required this.bookings, required this.revenueL});
}

final List<MonthRevenue> monthlyRevenue = [
  MonthRevenue(month: 'M1',  bookings: 60,  revenueL: 1.76),
  MonthRevenue(month: 'M2',  bookings: 70,  revenueL: 2.05),
  MonthRevenue(month: 'M3',  bookings: 80,  revenueL: 2.34),
  MonthRevenue(month: 'M4',  bookings: 95,  revenueL: 2.78),
  MonthRevenue(month: 'M5',  bookings: 110, revenueL: 3.22),
  MonthRevenue(month: 'M6',  bookings: 130, revenueL: 3.81),
  MonthRevenue(month: 'M7',  bookings: 150, revenueL: 4.39),
  MonthRevenue(month: 'M8',  bookings: 170, revenueL: 4.98),
  MonthRevenue(month: 'M9',  bookings: 200, revenueL: 5.85),
  MonthRevenue(month: 'M10', bookings: 230, revenueL: 6.72),
  MonthRevenue(month: 'M11', bookings: 260, revenueL: 7.60),
  MonthRevenue(month: 'M12', bookings: 300, revenueL: 8.78),
];

class InvestmentItem {
  final String category;
  final String amount;
  final double percentage;
  const InvestmentItem({required this.category, required this.amount, required this.percentage});
}

final List<InvestmentItem> investmentBreakdown = [
  InvestmentItem(category: 'Technology', amount: '₹10,00,000', percentage: 20),
  InvestmentItem(category: 'Training Centres', amount: '₹5,00,000', percentage: 20),
  InvestmentItem(category: 'Marketing & Launch', amount: '₹4,37,500', percentage: 25),
  InvestmentItem(category: 'Operations', amount: '₹4,37,500', percentage: 25),
  InvestmentItem(category: 'Contingency', amount: '₹1,75,000', percentage: 10),
];
