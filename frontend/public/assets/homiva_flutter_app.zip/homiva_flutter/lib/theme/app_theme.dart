import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class HomivaTheme {
  // ── Colours ──────────────────────────────────────────
  static const Color cream       = Color(0xFFFAF8F5);
  static const Color warmWhite   = Color(0xFFFFFEF9);
  static const Color charcoal    = Color(0xFF2A2724);
  static const Color dark        = Color(0xFF1C1A18);
  static const Color coral       = Color(0xFFE05A47);
  static const Color coralLight  = Color(0xFFF2836E);
  static const Color taupe       = Color(0xFF8A7F74);
  static const Color muted       = Color(0xFFC4BAB0);
  static const Color borderColor = Color(0xFFEAE5DE);
  static const Color accentWarm  = Color(0xFFF5EDE0);
  static const Color cardBg      = Color(0xFFFFFFFF);

  // ── Text Styles ───────────────────────────────────────
  static TextStyle displayLarge(BuildContext context) => GoogleFonts.dmSerifDisplay(
    fontSize: 36, fontWeight: FontWeight.w600, color: dark, height: 1.1,
  );

  static TextStyle headingMedium(BuildContext context) => GoogleFonts.dmSerifDisplay(
    fontSize: 24, fontWeight: FontWeight.w600, color: dark, height: 1.2,
  );

  static TextStyle headingSmall(BuildContext context) => GoogleFonts.dmSerifDisplay(
    fontSize: 18, fontWeight: FontWeight.w500, color: dark,
  );

  static TextStyle bodyLarge(BuildContext context) => GoogleFonts.dmSans(
    fontSize: 15, color: taupe, height: 1.7,
  );

  static TextStyle bodySmall(BuildContext context) => GoogleFonts.dmSans(
    fontSize: 12, color: taupe, height: 1.5,
  );

  static TextStyle labelStyle(BuildContext context) => GoogleFonts.dmSans(
    fontSize: 11, fontWeight: FontWeight.w700, color: coral,
    letterSpacing: 1.2,
  );

  // ── ThemeData ─────────────────────────────────────────
  static ThemeData get theme => ThemeData(
    useMaterial3: true,
    scaffoldBackgroundColor: cream,
    colorScheme: ColorScheme.fromSeed(
      seedColor: coral,
      primary: coral,
      secondary: charcoal,
      surface: cream,
      background: cream,
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: cream,
      elevation: 0,
      scrolledUnderElevation: 1,
      surfaceTintColor: cream,
      titleTextStyle: GoogleFonts.dmSerifDisplay(
        fontSize: 20, fontWeight: FontWeight.w600, color: dark,
      ),
      iconTheme: const IconThemeData(color: charcoal),
    ),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: cardBg,
      selectedItemColor: coral,
      unselectedItemColor: muted,
      type: BottomNavigationBarType.fixed,
      elevation: 12,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: coral,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
        textStyle: GoogleFonts.dmSans(fontSize: 15, fontWeight: FontWeight.w600),
        elevation: 0,
      ),
    ),
    cardTheme: CardTheme(
      color: cardBg,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: const BorderSide(color: borderColor),
      ),
    ),
  );
}
