import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';

// ── Section Tag ───────────────────────────────────────────────────────────────
class SectionTag extends StatelessWidget {
  final String text;
  final Color color;
  const SectionTag({super.key, required this.text, this.color = HomivaTheme.coral});

  @override
  Widget build(BuildContext context) {
    return Text(
      text.toUpperCase(),
      style: GoogleFonts.dmSans(
        fontSize: 11, fontWeight: FontWeight.w700,
        color: color, letterSpacing: 1.4,
      ),
    );
  }
}

// ── Section Heading ───────────────────────────────────────────────────────────
class SectionHeading extends StatelessWidget {
  final String text;
  final Color color;
  const SectionHeading({super.key, required this.text, this.color = HomivaTheme.dark});

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: GoogleFonts.dmSerifDisplay(
        fontSize: 26, fontWeight: FontWeight.w600,
        color: color, height: 1.2,
      ),
    );
  }
}

// ── Coral Button ──────────────────────────────────────────────────────────────
class CoralButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final bool outlined;
  const CoralButton({super.key, required this.label, this.onTap, this.outlined = false});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
        decoration: BoxDecoration(
          color: outlined ? Colors.transparent : HomivaTheme.coral,
          border: Border.all(
            color: outlined ? HomivaTheme.coral : Colors.transparent, width: 1.5,
          ),
          borderRadius: BorderRadius.circular(12),
          boxShadow: outlined ? null : [
            BoxShadow(color: HomivaTheme.coral.withOpacity(0.25), blurRadius: 16, offset: const Offset(0, 6)),
          ],
        ),
        child: Text(
          label,
          style: GoogleFonts.dmSans(
            fontSize: 14, fontWeight: FontWeight.w600,
            color: outlined ? HomivaTheme.coral : Colors.white,
          ),
        ),
      ),
    );
  }
}

// ── Stat Chip ─────────────────────────────────────────────────────────────────
class StatChip extends StatelessWidget {
  final String value;
  final String label;
  const StatChip({super.key, required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(value, style: GoogleFonts.dmSerifDisplay(
          fontSize: 28, fontWeight: FontWeight.w600, color: HomivaTheme.dark,
        )),
        const SizedBox(height: 2),
        Text(label, style: GoogleFonts.dmSans(
          fontSize: 11, color: HomivaTheme.taupe, letterSpacing: 0.3,
        )),
      ],
    );
  }
}

// ── Homiva Logo ───────────────────────────────────────────────────────────────
class HomivaLogo extends StatelessWidget {
  final double size;
  const HomivaLogo({super.key, this.size = 40});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        color: HomivaTheme.accentWarm,
        borderRadius: BorderRadius.circular(size * 0.22),
      ),
      child: Center(
        child: Text(
          'h',
          style: GoogleFonts.dmSerifDisplay(
            fontSize: size * 0.55, color: HomivaTheme.dark, fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}

// ── USP Pill Badge ────────────────────────────────────────────────────────────
class UspBadge extends StatelessWidget {
  final String emoji;
  final String text;
  const UspBadge({super.key, required this.emoji, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: HomivaTheme.accentWarm,
        border: Border.all(color: const Color(0xFFE8D9C4)),
        borderRadius: BorderRadius.circular(100),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 13)),
          const SizedBox(width: 6),
          Text(text, style: GoogleFonts.dmSans(
            fontSize: 12, fontWeight: FontWeight.w600, color: HomivaTheme.charcoal,
          )),
        ],
      ),
    );
  }
}

// ── Section Padding ───────────────────────────────────────────────────────────
class SectionPad extends StatelessWidget {
  final Widget child;
  final Color? color;
  const SectionPad({super.key, required this.child, this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: color,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
      child: child,
    );
  }
}

// ── Divider Line ──────────────────────────────────────────────────────────────
class HomivaDivider extends StatelessWidget {
  const HomivaDivider({super.key});
  @override
  Widget build(BuildContext context) {
    return const Divider(color: HomivaTheme.borderColor, height: 1);
  }
}

// ── Fin Row ───────────────────────────────────────────────────────────────────
class FinRow extends StatelessWidget {
  final String label;
  final String value;
  const FinRow({super.key, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(child: Text(label, style: GoogleFonts.dmSans(fontSize: 13, color: HomivaTheme.taupe))),
          Text(value, style: GoogleFonts.dmSans(fontSize: 13, fontWeight: FontWeight.w600, color: HomivaTheme.dark)),
        ],
      ),
    );
  }
}

// ── Dark Highlight Card ────────────────────────────────────────────────────────
class DarkHighlightCard extends StatelessWidget {
  final String label;
  final String amount;
  final String emoji;
  const DarkHighlightCard({super.key, required this.label, required this.amount, required this.emoji});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 16),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
      decoration: BoxDecoration(
        color: HomivaTheme.dark,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: GoogleFonts.dmSans(fontSize: 11, color: Colors.white54)),
              const SizedBox(height: 4),
              Text(amount, style: GoogleFonts.dmSerifDisplay(fontSize: 22, color: Colors.white, fontWeight: FontWeight.w600)),
            ],
          ),
          Text(emoji, style: const TextStyle(fontSize: 28)),
        ],
      ),
    );
  }
}
