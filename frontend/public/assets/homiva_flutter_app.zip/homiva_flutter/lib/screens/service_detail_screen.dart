import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../models/data.dart';
import '../widgets/common_widgets.dart';

class ServiceDetailScreen extends StatelessWidget {
  final ServiceModel service;
  const ServiceDetailScreen({super.key, required this.service});

  static const List<Color> _heroColors = [
    Color(0xFFFFF3F1), Color(0xFFF0F8FF), Color(0xFFF0FFF4), Color(0xFFFFFAF0),
  ];

  @override
  Widget build(BuildContext context) {
    final heroColor = _heroColors[service.colorIndex % _heroColors.length];
    return Scaffold(
      backgroundColor: HomivaTheme.cream,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 200,
            floating: false,
            pinned: true,
            backgroundColor: heroColor,
            surfaceTintColor: heroColor,
            leading: GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                margin: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.arrow_back_ios_new, color: HomivaTheme.dark, size: 18),
              ),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                color: heroColor,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(height: 60),
                    Text(service.emoji, style: const TextStyle(fontSize: 64)),
                    const SizedBox(height: 8),
                    Text(service.title, style: GoogleFonts.dmSerifDisplay(
                      fontSize: 28, fontWeight: FontWeight.w600, color: HomivaTheme.dark,
                    )),
                    Text(service.subtitle, style: GoogleFonts.dmSans(
                      fontSize: 13, color: HomivaTheme.taupe,
                    )),
                  ],
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Price + Revenue strip
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: HomivaTheme.dark,
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _MetricTile(label: 'Avg. Price', value: service.avgPrice, emoji: '💰'),
                        _MetricTile(label: 'Platform Fee', value: service.commission, emoji: '📊'),
                        _MetricTile(label: 'Monthly Rev', value: service.monthlyRevenue, emoji: '📈'),
                        _MetricTile(label: 'Share', value: service.revenueShare, emoji: '🥧'),
                      ],
                    ),
                  ),
                  const SizedBox(height: 28),

                  // Description
                  const SectionTag(text: 'About This Service'),
                  const SizedBox(height: 10),
                  Text(service.description, style: GoogleFonts.dmSans(
                    fontSize: 14, color: HomivaTheme.taupe, height: 1.75,
                  )),
                  const SizedBox(height: 28),

                  // Features
                  const SectionTag(text: 'Services Included'),
                  const SizedBox(height: 12),
                  ...service.features.map((f) => Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 22, height: 22,
                          decoration: BoxDecoration(
                            color: HomivaTheme.coral.withOpacity(0.12),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.check, color: HomivaTheme.coral, size: 13),
                        ),
                        const SizedBox(width: 12),
                        Expanded(child: Text(f, style: GoogleFonts.dmSans(
                          fontSize: 14, color: HomivaTheme.charcoal, height: 1.4,
                        ))),
                      ],
                    ),
                  )),
                  const SizedBox(height: 28),

                  // Tags
                  const SectionTag(text: 'Service Tags'),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 10, runSpacing: 10,
                    children: service.tags.map((tag) => Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        color: HomivaTheme.accentWarm,
                        border: Border.all(color: const Color(0xFFE8D9C4)),
                        borderRadius: BorderRadius.circular(100),
                      ),
                      child: Text(tag, style: GoogleFonts.dmSans(
                        fontSize: 12, fontWeight: FontWeight.w500, color: HomivaTheme.taupe,
                      )),
                    )).toList(),
                  ),
                  const SizedBox(height: 36),

                  // Booking CTA
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {},
                      style: ElevatedButton.styleFrom(
                        backgroundColor: HomivaTheme.coral,
                        padding: const EdgeInsets.symmetric(vertical: 18),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        elevation: 0,
                      ),
                      child: Text('Book ${service.title} Now',
                        style: GoogleFonts.dmSans(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white)),
                    ),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: HomivaTheme.borderColor),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                      child: Text('Back to Services',
                        style: GoogleFonts.dmSans(fontSize: 14, fontWeight: FontWeight.w500, color: HomivaTheme.taupe)),
                    ),
                  ),
                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MetricTile extends StatelessWidget {
  final String label, value, emoji;
  const _MetricTile({required this.label, required this.value, required this.emoji});
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(emoji, style: const TextStyle(fontSize: 18)),
        const SizedBox(height: 6),
        Text(value, style: GoogleFonts.dmSerifDisplay(fontSize: 15, fontWeight: FontWeight.w600, color: Colors.white)),
        const SizedBox(height: 2),
        Text(label, style: GoogleFonts.dmSans(fontSize: 10, color: Colors.white54)),
      ],
    );
  }
}
