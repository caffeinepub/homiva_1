import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:fl_chart/fl_chart.dart';
import '../theme/app_theme.dart';
import '../models/data.dart';
import '../widgets/common_widgets.dart';

class FinancialsScreen extends StatelessWidget {
  const FinancialsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: HomivaTheme.cream,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            floating: true, snap: true,
            title: Text('Financials', style: GoogleFonts.dmSerifDisplay(
              fontSize: 20, fontWeight: FontWeight.w600, color: HomivaTheme.dark,
            )),
            backgroundColor: HomivaTheme.cream,
            surfaceTintColor: HomivaTheme.cream,
            elevation: 0,
            automaticallyImplyLeading: false,
          ),
          SliverToBoxAdapter(
            child: Column(
              children: [
                _buildSummaryCards(),
                _buildRevenueChart(),
                _buildSectorRevenue(),
                _buildInvestmentBreakdown(),
                _buildMonthlyBurn(),
                _buildInvestorAsk(),
                const SizedBox(height: 40),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryCards() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 20),
      child: Row(
        children: [
          Expanded(child: _SummaryCard(emoji: '💰', label: 'Year-1 Revenue', value: '₹51 Lakhs', color: HomivaTheme.coral)),
          const SizedBox(width: 14),
          Expanded(child: _SummaryCard(emoji: '📅', label: 'Break-Even', value: '18–24 Months', color: HomivaTheme.charcoal)),
        ],
      ),
    );
  }

  Widget _buildRevenueChart() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: HomivaTheme.cardBg,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: HomivaTheme.borderColor),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SectionTag(text: '12-Month Projection'),
            const SizedBox(height: 8),
            const SectionHeading(text: 'Revenue Growth'),
            const SizedBox(height: 4),
            Text('Monthly commission revenue (₹ Lakhs)',
              style: GoogleFonts.dmSans(fontSize: 12, color: HomivaTheme.taupe)),
            const SizedBox(height: 24),
            SizedBox(
              height: 200,
              child: BarChart(
                BarChartData(
                  alignment: BarChartAlignment.spaceAround,
                  maxY: 10,
                  barTouchData: BarTouchData(
                    touchTooltipData: BarTouchTooltipData(
                      tooltipBgColor: HomivaTheme.dark,
                      getTooltipItem: (group, groupIndex, rod, rodIndex) {
                        final m = monthlyRevenue[groupIndex];
                        return BarTooltipItem(
                          '${m.month}\n₹${m.revenueL}L',
                          GoogleFonts.dmSans(fontSize: 11, color: Colors.white, height: 1.5),
                        );
                      },
                    ),
                  ),
                  titlesData: FlTitlesData(
                    show: true,
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true, reservedSize: 22,
                        getTitlesWidget: (v, meta) {
                          final idx = v.toInt();
                          if (idx < 0 || idx >= monthlyRevenue.length) return const SizedBox();
                          return Text(monthlyRevenue[idx].month,
                            style: GoogleFonts.dmSans(fontSize: 9, color: HomivaTheme.taupe));
                        },
                      ),
                    ),
                    leftTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true, reservedSize: 32,
                        getTitlesWidget: (v, meta) => Text(
                          '₹${v.toInt()}L',
                          style: GoogleFonts.dmSans(fontSize: 9, color: HomivaTheme.muted),
                        ),
                      ),
                    ),
                    topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  ),
                  gridData: FlGridData(
                    show: true,
                    drawVerticalLine: false,
                    getDrawingHorizontalLine: (v) => FlLine(
                      color: HomivaTheme.borderColor, strokeWidth: 1,
                    ),
                  ),
                  borderData: FlBorderData(show: false),
                  barGroups: monthlyRevenue.asMap().entries.map((e) {
                    return BarChartGroupData(
                      x: e.key,
                      barRods: [
                        BarChartRodData(
                          toY: e.value.revenueL,
                          color: HomivaTheme.coral,
                          width: 18,
                          borderRadius: const BorderRadius.vertical(top: Radius.circular(6)),
                          backDrawRodData: BackgroundBarChartRodData(
                            show: true, toY: 10, color: HomivaTheme.accentWarm,
                          ),
                        ),
                      ],
                    );
                  }).toList(),
                ),
              ),
            ),
            const SizedBox(height: 16),
            const DarkHighlightCard(label: 'Total Year-1 Revenue', amount: '≈ ₹51 Lakhs', emoji: '📈'),
          ],
        ),
      ),
    );
  }

  Widget _buildSectorRevenue() {
    final sectors = [
      {'emoji': '🏥', 'name': 'Elderly Care', 'share': '36%', 'revenue': '₹68,250/mo', 'pct': 0.36},
      {'emoji': '👶', 'name': 'Babysitting',  'share': '26%', 'revenue': '₹48,750/mo', 'pct': 0.26},
      {'emoji': '🏠', 'name': 'Household Help','share': '24%', 'revenue': '₹45,500/mo', 'pct': 0.24},
      {'emoji': '🐾', 'name': 'Pet Care',      'share': '14%', 'revenue': '₹26,000/mo', 'pct': 0.14},
    ];

    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionTag(text: 'Sector Revenue'),
          const SizedBox(height: 8),
          const SectionHeading(text: 'Monthly Contribution'),
          const SizedBox(height: 16),
          ...sectors.map((s) => Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: HomivaTheme.cardBg,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: HomivaTheme.borderColor),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(children: [
                      Text(s['emoji'] as String, style: const TextStyle(fontSize: 22)),
                      const SizedBox(width: 10),
                      Text(s['name'] as String, style: GoogleFonts.dmSans(
                        fontSize: 14, fontWeight: FontWeight.w600, color: HomivaTheme.dark,
                      )),
                    ]),
                    Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                      Text(s['share'] as String, style: GoogleFonts.dmSerifDisplay(
                        fontSize: 18, fontWeight: FontWeight.w600, color: HomivaTheme.coral,
                      )),
                      Text(s['revenue'] as String, style: GoogleFonts.dmSans(
                        fontSize: 11, color: HomivaTheme.taupe,
                      )),
                    ]),
                  ],
                ),
                const SizedBox(height: 10),
                LinearProgressIndicator(
                  value: s['pct'] as double,
                  backgroundColor: HomivaTheme.accentWarm,
                  valueColor: const AlwaysStoppedAnimation<Color>(HomivaTheme.coral),
                  minHeight: 6,
                  borderRadius: BorderRadius.circular(4),
                ),
              ],
            ),
          )),
        ],
      ),
    );
  }

  Widget _buildInvestmentBreakdown() {
    return Container(
      color: HomivaTheme.accentWarm,
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionTag(text: 'Initial Investment'),
          const SizedBox(height: 8),
          const SectionHeading(text: 'Setup Cost Breakdown'),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: HomivaTheme.cardBg,
              borderRadius: BorderRadius.circular(18),
            ),
            child: Column(
              children: [
                const FinRow(label: 'Technology (App + Backend)', value: '₹10,00,000'),
                const HomivaDivider(),
                const FinRow(label: 'Training Centre Setup (3)', value: '₹5,00,000'),
                const HomivaDivider(),
                const FinRow(label: 'Legal & Compliance', value: '₹1,50,000'),
                const HomivaDivider(),
                const FinRow(label: 'Branding & Marketing Launch', value: '₹80,000'),
                const DarkHighlightCard(label: 'Total Initial Investment', amount: '₹17 Lakhs', emoji: '💼'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMonthlyBurn() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionTag(text: 'Monthly Operations'),
          const SizedBox(height: 8),
          const SectionHeading(text: 'Monthly Burn Rate'),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: HomivaTheme.cardBg,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: HomivaTheme.borderColor),
            ),
            child: Column(
              children: [
                const FinRow(label: '9 Trainers × ₹25,000', value: '₹2,25,000'),
                const HomivaDivider(),
                const FinRow(label: '3 Centre Rents × ₹15,000', value: '₹45,000'),
                const HomivaDivider(),
                const FinRow(label: 'Operations Team', value: '₹1,55,000'),
                const HomivaDivider(),
                const FinRow(label: 'Technology Maintenance', value: '₹50,000'),
                const HomivaDivider(),
                const FinRow(label: 'Marketing Budget', value: '₹70,000'),
                const HomivaDivider(),
                const FinRow(label: 'Miscellaneous', value: '₹70,000'),
                const DarkHighlightCard(label: 'Monthly Burn Rate', amount: '₹6.15L / month', emoji: '🔥'),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: _SmallMetric(label: '12-Month Ops', value: '₹73.8L')),
              const SizedBox(width: 12),
              Expanded(child: _SmallMetric(label: 'Year-1 Capital', value: '≈ ₹1 Crore')),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInvestorAsk() {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 0, 20, 20),
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        color: HomivaTheme.coral,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [BoxShadow(color: HomivaTheme.coral.withOpacity(0.3), blurRadius: 20, offset: const Offset(0, 8))],
      ),
      child: Column(
        children: [
          Text('Investor Ask', style: GoogleFonts.dmSans(
            fontSize: 11, fontWeight: FontWeight.w700, color: Colors.white60, letterSpacing: 1.4,
          )),
          const SizedBox(height: 8),
          Text('₹1.5 Crore\nSeed Investment', textAlign: TextAlign.center,
            style: GoogleFonts.dmSerifDisplay(fontSize: 28, fontWeight: FontWeight.w700, color: Colors.white, height: 1.2)),
          const SizedBox(height: 20),
          ...investmentBreakdown.map((item) => Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(item.category, style: GoogleFonts.dmSans(fontSize: 13, color: Colors.white70)),
                Row(children: [
                  Container(
                    width: 80, height: 6,
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(3), color: Colors.white.withOpacity(0.15)),
                    child: FractionallySizedBox(
                      widthFactor: item.percentage / 100,
                      alignment: Alignment.centerLeft,
                      child: Container(decoration: BoxDecoration(borderRadius: BorderRadius.circular(3), color: Colors.white)),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text('${item.percentage.toInt()}%', style: GoogleFonts.dmSans(fontSize: 13, fontWeight: FontWeight.w700, color: Colors.white)),
                ]),
              ],
            ),
          )),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _InvStat(label: 'Break-Even', value: '24 mo'),
                _InvStat(label: 'Workers/yr', value: '500+'),
                _InvStat(label: 'Centres', value: '3'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final String emoji, label, value;
  final Color color;
  const _SummaryCard({required this.emoji, required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: HomivaTheme.cardBg,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: HomivaTheme.borderColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 28)),
          const SizedBox(height: 8),
          Text(value, style: GoogleFonts.dmSerifDisplay(fontSize: 18, fontWeight: FontWeight.w600, color: color)),
          const SizedBox(height: 2),
          Text(label, style: GoogleFonts.dmSans(fontSize: 11, color: HomivaTheme.taupe)),
        ],
      ),
    );
  }
}

class _SmallMetric extends StatelessWidget {
  final String label, value;
  const _SmallMetric({required this.label, required this.value});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: HomivaTheme.accentWarm,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        children: [
          Text(value, style: GoogleFonts.dmSerifDisplay(fontSize: 18, fontWeight: FontWeight.w600, color: HomivaTheme.dark)),
          const SizedBox(height: 4),
          Text(label, style: GoogleFonts.dmSans(fontSize: 11, color: HomivaTheme.taupe)),
        ],
      ),
    );
  }
}

class _InvStat extends StatelessWidget {
  final String label, value;
  const _InvStat({required this.label, required this.value});
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(value, style: GoogleFonts.dmSerifDisplay(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.white)),
        const SizedBox(height: 2),
        Text(label, style: GoogleFonts.dmSans(fontSize: 10, color: Colors.white60)),
      ],
    );
  }
}
