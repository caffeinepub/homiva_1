import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../models/data.dart';
import '../widgets/common_widgets.dart';

class SafetyScreen extends StatelessWidget {
  const SafetyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: HomivaTheme.cream,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            floating: true, snap: true,
            title: Text('Trust & Safety', style: GoogleFonts.dmSerifDisplay(
              fontSize: 20, fontWeight: FontWeight.w600, color: HomivaTheme.dark,
            )),
            backgroundColor: HomivaTheme.cream,
            surfaceTintColor: HomivaTheme.cream,
            elevation: 0,
            automaticallyImplyLeading: false,
          ),
          SliverToBoxAdapter(
            child: Column(
              children: [
                _buildHeroCard(),
                _buildSafetySteps(),
                _buildUspGrid(),
                _buildVerifiedBadge(),
                const SizedBox(height: 32),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeroCard() {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 4, 20, 0),
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        color: HomivaTheme.dark,
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('🛡️', style: TextStyle(fontSize: 44)),
          const SizedBox(height: 14),
          Text('Our Safety is\nYour Peace of Mind',
            style: GoogleFonts.dmSerifDisplay(fontSize: 26, fontWeight: FontWeight.w600, color: Colors.white, height: 1.15)),
          const SizedBox(height: 12),
          Text(
            'Every HOMIVA service partner goes through a 6-layer verification process before reaching your home.',
            style: GoogleFonts.dmSans(fontSize: 13, color: Colors.white54, height: 1.65),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              _SafetyBadge(label: 'KYC Verified', icon: Icons.badge_outlined),
              const SizedBox(width: 10),
              _SafetyBadge(label: 'Police Cleared', icon: Icons.shield_outlined),
              const SizedBox(width: 10),
              _SafetyBadge(label: 'GPS Tracked', icon: Icons.location_on_outlined),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSafetySteps() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionTag(text: '6-Layer Verification'),
          const SizedBox(height: 8),
          const SectionHeading(text: 'How We Verify Every Partner'),
          const SizedBox(height: 20),
          ...safetySteps.asMap().entries.map((e) {
            final step = e.value;
            final isLast = e.key == safetySteps.length - 1;
            return Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  children: [
                    Container(
                      width: 40, height: 40,
                      decoration: BoxDecoration(
                        color: HomivaTheme.coral,
                        shape: BoxShape.circle,
                        boxShadow: [BoxShadow(color: HomivaTheme.coral.withOpacity(0.3), blurRadius: 10)],
                      ),
                      child: Center(child: Text('${step.step}',
                        style: GoogleFonts.dmSans(fontSize: 13, fontWeight: FontWeight.w700, color: Colors.white))),
                    ),
                    if (!isLast) Container(width: 2, height: 60, color: HomivaTheme.borderColor),
                  ],
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Container(
                    margin: EdgeInsets.only(bottom: isLast ? 0 : 20),
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: HomivaTheme.cardBg,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: HomivaTheme.borderColor),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(step.emoji, style: const TextStyle(fontSize: 20)),
                            const SizedBox(width: 10),
                            Text(step.title, style: GoogleFonts.dmSans(
                              fontSize: 14, fontWeight: FontWeight.w700, color: HomivaTheme.dark,
                            )),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(step.description, style: GoogleFonts.dmSans(
                          fontSize: 13, color: HomivaTheme.taupe, height: 1.55,
                        )),
                      ],
                    ),
                  ),
                ),
              ],
            );
          }),
        ],
      ),
    );
  }

  Widget _buildUspGrid() {
    return Container(
      color: HomivaTheme.accentWarm,
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionTag(text: 'Our Unique Advantages'),
          const SizedBox(height: 8),
          const SectionHeading(text: 'What Makes HOMIVA Different'),
          const SizedBox(height: 20),
          GridView.count(
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            crossAxisCount: 2,
            childAspectRatio: 1.4,
            crossAxisSpacing: 14,
            mainAxisSpacing: 14,
            children: homIvaUsps.map((u) => Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: HomivaTheme.cardBg,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(u.emoji, style: const TextStyle(fontSize: 26)),
                  const SizedBox(height: 8),
                  Text(u.title, style: GoogleFonts.dmSans(fontSize: 13, fontWeight: FontWeight.w700, color: HomivaTheme.dark)),
                  const SizedBox(height: 4),
                  Text(u.description, style: GoogleFonts.dmSans(fontSize: 11, color: HomivaTheme.taupe, height: 1.4), maxLines: 2, overflow: TextOverflow.ellipsis),
                ],
              ),
            )).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildVerifiedBadge() {
    return Container(
      margin: const EdgeInsets.all(20),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [HomivaTheme.coral.withOpacity(0.08), HomivaTheme.accentWarm],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: HomivaTheme.coral.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Container(
            width: 60, height: 60,
            decoration: BoxDecoration(
              color: HomivaTheme.coral,
              shape: BoxShape.circle,
            ),
            child: const Center(child: Text('✓', style: TextStyle(fontSize: 28, color: Colors.white, fontWeight: FontWeight.bold))),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('HOMIVA Certified Partner', style: GoogleFonts.dmSans(
                  fontSize: 15, fontWeight: FontWeight.w700, color: HomivaTheme.dark,
                )),
                const SizedBox(height: 4),
                Text('All partners are trained, certified and approved before their first booking.',
                  style: GoogleFonts.dmSans(fontSize: 12, color: HomivaTheme.taupe, height: 1.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SafetyBadge extends StatelessWidget {
  final String label;
  final IconData icon;
  const _SafetyBadge({required this.label, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        border: Border.all(color: Colors.white.withOpacity(0.12)),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: HomivaTheme.coral, size: 13),
          const SizedBox(width: 5),
          Text(label, style: GoogleFonts.dmSans(fontSize: 10, fontWeight: FontWeight.w600, color: Colors.white70)),
        ],
      ),
    );
  }
}
