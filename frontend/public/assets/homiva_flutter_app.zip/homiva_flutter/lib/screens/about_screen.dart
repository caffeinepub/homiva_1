import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../models/data.dart';
import '../widgets/common_widgets.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: HomivaTheme.cream,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            floating: true, snap: true,
            title: Text('About HOMIVA', style: GoogleFonts.dmSerifDisplay(
              fontSize: 20, fontWeight: FontWeight.w600, color: HomivaTheme.dark,
            )),
            backgroundColor: HomivaTheme.cream,
            surfaceTintColor: HomivaTheme.cream,
            elevation: 0,
            automaticallyImplyLeading: false,
          ),
          SliverToBoxAdapter(
            child: Column(
              children: [
                _buildBrandSection(),
                _buildMissionSection(),
                _buildMarketingStrategy(),
                _buildTeamSection(),
                _buildFooter(),
                const SizedBox(height: 32),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBrandSection() {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 4, 20, 0),
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [Color(0xFFFFF3F1), Color(0xFFF5EDE0)],
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: HomivaTheme.borderColor),
      ),
      child: Column(
        children: [
          Container(
            width: 80, height: 80,
            decoration: BoxDecoration(
              color: HomivaTheme.dark,
              borderRadius: BorderRadius.circular(22),
            ),
            child: Center(
              child: Text('h', style: GoogleFonts.dmSerifDisplay(
                fontSize: 44, color: Colors.white, fontWeight: FontWeight.w600,
              )),
            ),
          ),
          const SizedBox(height: 16),
          Text('homiva', style: GoogleFonts.dmSerifDisplay(
            fontSize: 32, fontWeight: FontWeight.w600, color: HomivaTheme.dark,
          )),
          const SizedBox(height: 6),
          Text('care that comes home', style: GoogleFonts.dmSans(
            fontSize: 14, color: HomivaTheme.taupe, letterSpacing: 0.5,
          )),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: HomivaTheme.coral.withOpacity(0.1),
              border: Border.all(color: HomivaTheme.coral.withOpacity(0.25)),
              borderRadius: BorderRadius.circular(100),
            ),
            child: Text('Marketing Management Assignment · Group 4',
              style: GoogleFonts.dmSans(fontSize: 12, color: HomivaTheme.coral, fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  Widget _buildMissionSection() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionTag(text: 'Our Mission'),
          const SizedBox(height: 8),
          const SectionHeading(text: 'Why We Built HOMIVA'),
          const SizedBox(height: 14),
          Text(
            'In today\'s urban lifestyle, families face difficulty finding reliable, safe, and flexible home care services for elderly people, children, pets, and daily household tasks.',
            style: GoogleFonts.dmSans(fontSize: 14, color: HomivaTheme.taupe, height: 1.75),
          ),
          const SizedBox(height: 12),
          Text(
            'Most services are unorganized, lack proper verification, and require long waiting times. HOMIVA bridges this gap by offering four essential home care services through one trusted mobile application — hyper-local, verified, and within 15–20 minutes.',
            style: GoogleFonts.dmSans(fontSize: 14, color: HomivaTheme.taupe, height: 1.75),
          ),
          const SizedBox(height: 24),
          _buildProblemStatement(),
        ],
      ),
    );
  }

  Widget _buildProblemStatement() {
    final points = [
      'Difficulty finding reliable and trustworthy providers',
      'No single platform offering multiple home services',
      'Safety concerns for elderly people and children',
      'Unorganized providers with no accountability',
      'Time-consuming process of searching helpers',
    ];
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: HomivaTheme.accentWarm,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Problem Statement', style: GoogleFonts.dmSans(
            fontSize: 12, fontWeight: FontWeight.w700, color: HomivaTheme.coral, letterSpacing: 1.2,
          )),
          const SizedBox(height: 12),
          ...points.map((p) => Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('•', style: TextStyle(color: HomivaTheme.coral, fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(width: 10),
                Expanded(child: Text(p, style: GoogleFonts.dmSans(fontSize: 13, color: HomivaTheme.charcoal, height: 1.5))),
              ],
            ),
          )),
        ],
      ),
    );
  }

  Widget _buildMarketingStrategy() {
    final strategies = [
      {'icon': '📱', 'title': 'Digital Marketing', 'desc': 'Social media campaigns, SEO, targeted ads to reach urban households.'},
      {'icon': '📍', 'title': 'Local Area Promotion', 'desc': 'Flyers, word-of-mouth, and offline events within the 2 km service radius.'},
      {'icon': '🤝', 'title': 'Partnerships & Collaborations', 'desc': 'Women SHGs, NGOs, pet shops, and retirement communities.'},
      {'icon': '🎁', 'title': 'Referral Programs', 'desc': 'Reward customers who bring new users to the platform.'},
      {'icon': '⭐', 'title': 'Reviews & Ratings', 'desc': 'Build trust through transparent customer feedback systems.'},
      {'icon': '🏷️', 'title': 'Introductory Offers', 'desc': 'Discounted first bookings and subscription launch packages.'},
    ];

    return Container(
      color: HomivaTheme.dark,
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SectionTag(text: 'Go-To-Market', color: HomivaTheme.coral.withOpacity(0.9)),
          const SizedBox(height: 8),
          SectionHeading(text: 'Marketing Strategy', color: Colors.white),
          const SizedBox(height: 20),
          ...strategies.map((s) => Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.05),
              border: Border.all(color: Colors.white.withOpacity(0.08)),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              children: [
                Text(s['icon']!, style: const TextStyle(fontSize: 24)),
                const SizedBox(width: 14),
                Expanded(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(s['title']!, style: GoogleFonts.dmSans(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white)),
                    const SizedBox(height: 4),
                    Text(s['desc']!, style: GoogleFonts.dmSans(fontSize: 12, color: Colors.white54, height: 1.5)),
                  ],
                )),
              ],
            ),
          )),
        ],
      ),
    );
  }

  Widget _buildTeamSection() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionTag(text: 'The Team'),
          const SizedBox(height: 8),
          const SectionHeading(text: 'Group 4 — Creators of HOMIVA'),
          const SizedBox(height: 6),
          Text('Marketing Management Assignment — Create, Brand & Launch Report',
            style: GoogleFonts.dmSans(fontSize: 13, color: HomivaTheme.taupe)),
          const SizedBox(height: 20),
          ...teamMembers.map((m) => Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            decoration: BoxDecoration(
              color: HomivaTheme.cardBg,
              border: Border.all(color: HomivaTheme.borderColor),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                Container(
                  width: 44, height: 44,
                  decoration: BoxDecoration(
                    color: HomivaTheme.accentWarm,
                    shape: BoxShape.circle,
                  ),
                  child: Center(child: Text(m.emoji, style: const TextStyle(fontSize: 22))),
                ),
                const SizedBox(width: 14),
                Text(m.name, style: GoogleFonts.dmSans(
                  fontSize: 15, fontWeight: FontWeight.w500, color: HomivaTheme.dark,
                )),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: HomivaTheme.accentWarm,
                    borderRadius: BorderRadius.circular(100),
                  ),
                  child: Text('Group 4', style: GoogleFonts.dmSans(fontSize: 10, color: HomivaTheme.taupe, fontWeight: FontWeight.w600)),
                ),
              ],
            ),
          )),
        ],
      ),
    );
  }

  Widget _buildFooter() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: HomivaTheme.coral,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        children: [
          const Text('🏠', style: TextStyle(fontSize: 36)),
          const SizedBox(height: 10),
          Text('homiva', style: GoogleFonts.dmSerifDisplay(fontSize: 22, color: Colors.white, fontWeight: FontWeight.w600)),
          Text('care that comes home', style: GoogleFonts.dmSans(fontSize: 12, color: Colors.white70, letterSpacing: 0.5)),
          const SizedBox(height: 16),
          Text('Kolkata, West Bengal  •  2 km Hyper-Local',
            style: GoogleFonts.dmSans(fontSize: 11, color: Colors.white54)),
        ],
      ),
    );
  }
}
