import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../models/data.dart';
import '../widgets/common_widgets.dart';
import 'service_detail_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: HomivaTheme.cream,
      body: CustomScrollView(
        slivers: [
          _buildSliverAppBar(context),
          SliverToBoxAdapter(child: _buildHeroSection(context)),
          SliverToBoxAdapter(child: _buildProblemSection(context)),
          SliverToBoxAdapter(child: _buildServicesSection(context)),
          SliverToBoxAdapter(child: _buildUspSection(context)),
          SliverToBoxAdapter(child: _buildTargetMarketSection(context)),
          SliverToBoxAdapter(child: _buildFooterCta(context)),
        ],
      ),
    );
  }

  // ── App Bar ──────────────────────────────────────────────────────────────────
  Widget _buildSliverAppBar(BuildContext context) {
    return SliverAppBar(
      expandedHeight: 0,
      floating: true,
      snap: true,
      backgroundColor: HomivaTheme.cream,
      surfaceTintColor: HomivaTheme.cream,
      elevation: 0,
      title: Row(
        children: [
          const HomivaLogo(size: 36),
          const SizedBox(width: 10),
          Text('homiva', style: GoogleFonts.dmSerifDisplay(
            fontSize: 22, fontWeight: FontWeight.w600, color: HomivaTheme.dark,
          )),
        ],
      ),
      actions: [
        Container(
          margin: const EdgeInsets.only(right: 16),
          decoration: BoxDecoration(
            color: HomivaTheme.coral.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: IconButton(
            icon: const Icon(Icons.notifications_outlined, color: HomivaTheme.coral, size: 22),
            onPressed: () {},
          ),
        ),
      ],
    );
  }

  // ── Hero Section ─────────────────────────────────────────────────────────────
  Widget _buildHeroSection(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 8, 20, 0),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [Color(0xFFFFF6F4), Color(0xFFF5EDE0)],
        ),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: HomivaTheme.borderColor),
      ),
      padding: const EdgeInsets.all(28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Live badge
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: HomivaTheme.coral.withOpacity(0.12),
              border: Border.all(color: HomivaTheme.coral.withOpacity(0.3)),
              borderRadius: BorderRadius.circular(100),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 6, height: 6,
                  decoration: const BoxDecoration(color: HomivaTheme.coral, shape: BoxShape.circle),
                ),
                const SizedBox(width: 6),
                Text('Kolkata-First Launch · 2 km Radius',
                  style: GoogleFonts.dmSans(
                    fontSize: 11, fontWeight: FontWeight.w600, color: HomivaTheme.coral, letterSpacing: 0.3,
                  )),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'Care That\nComes Home',
            style: GoogleFonts.dmSerifDisplay(
              fontSize: 38, fontWeight: FontWeight.w600,
              color: HomivaTheme.dark, height: 1.1,
            ),
          ),
          const SizedBox(height: 14),
          Text(
            'A trusted home care platform delivering elderly care, babysitting, household help and pet care — verified, safe, within 15–20 minutes.',
            style: GoogleFonts.dmSans(fontSize: 14, color: HomivaTheme.taupe, height: 1.7),
          ),
          const SizedBox(height: 24),
          // Stats row
          Row(
            children: const [
              StatChip(value: '4', label: 'Services'),
              SizedBox(width: 32),
              StatChip(value: '20m', label: 'Response'),
              SizedBox(width: 32),
              StatChip(value: '₹51L', label: 'Year-1 Target'),
            ],
          ),
          const SizedBox(height: 24),
          Row(
            children: [
              const CoralButton(label: 'Book a Service'),
              const SizedBox(width: 12),
              const CoralButton(label: 'Learn More', outlined: true),
            ],
          ),
        ],
      ),
    );
  }

  // ── Problem Section ───────────────────────────────────────────────────────────
  Widget _buildProblemSection(BuildContext context) {
    final problems = [
      {'emoji': '🔍', 'title': 'No Trusted Platform', 'desc': 'No single app with verified workers for multiple home services.'},
      {'emoji': '⚠️', 'title': 'Safety Concerns', 'desc': 'Informal helpers with no background checks — risky for elders & children.'},
      {'emoji': '⏳', 'title': 'Long Waiting Times', 'desc': 'No reliable on-demand option. Searching takes too long.'},
      {'emoji': '📋', 'title': 'No Accountability', 'desc': 'Informal arrangements lack contracts, training, or grievance systems.'},
    ];

    return Container(
      margin: const EdgeInsets.fromLTRB(0, 32, 0, 0),
      color: HomivaTheme.dark,
      padding: const EdgeInsets.all(28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SectionTag(text: 'The Problem We Solve', color: HomivaTheme.coral.withOpacity(0.9)),
          const SizedBox(height: 10),
          SectionHeading(text: 'Urban families deserve better', color: Colors.white),
          const SizedBox(height: 24),
          ...problems.map((p) => Container(
            margin: const EdgeInsets.only(bottom: 14),
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.05),
              border: Border.all(color: Colors.white.withOpacity(0.08)),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                Text(p['emoji']!, style: const TextStyle(fontSize: 26)),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(p['title']!, style: GoogleFonts.dmSans(
                        fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white,
                      )),
                      const SizedBox(height: 4),
                      Text(p['desc']!, style: GoogleFonts.dmSans(
                        fontSize: 12, color: Colors.white54, height: 1.5,
                      )),
                    ],
                  ),
                ),
              ],
            ),
          )),
        ],
      ),
    );
  }

  // ── Services Section ──────────────────────────────────────────────────────────
  Widget _buildServicesSection(BuildContext context) {
    return SectionPad(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionTag(text: 'What We Offer'),
          const SizedBox(height: 8),
          const SectionHeading(text: 'Four Essential Services, One Trusted App'),
          const SizedBox(height: 6),
          Text('Every partner is KYC-verified, police-cleared, and trained.',
            style: GoogleFonts.dmSans(fontSize: 13, color: HomivaTheme.taupe)),
          const SizedBox(height: 24),
          ...homIvaServices.map((svc) => _ServiceCard(service: svc)),
        ],
      ),
    );
  }

  // ── USP Section ───────────────────────────────────────────────────────────────
  Widget _buildUspSection(BuildContext context) {
    return Container(
      color: HomivaTheme.accentWarm,
      padding: const EdgeInsets.all(28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionTag(text: 'Why HOMIVA'),
          const SizedBox(height: 8),
          const SectionHeading(text: 'Trust, Speed & Convenience'),
          const SizedBox(height: 24),
          GridView.count(
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            crossAxisCount: 2,
            childAspectRatio: 1.35,
            crossAxisSpacing: 14,
            mainAxisSpacing: 14,
            children: homIvaUsps.map((u) => Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: HomivaTheme.cardBg,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8)],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(u.emoji, style: const TextStyle(fontSize: 26)),
                  const SizedBox(height: 8),
                  Text(u.title, style: GoogleFonts.dmSans(
                    fontSize: 13, fontWeight: FontWeight.w700, color: HomivaTheme.dark,
                  )),
                  const SizedBox(height: 4),
                  Text(u.description, style: GoogleFonts.dmSans(
                    fontSize: 11, color: HomivaTheme.taupe, height: 1.4,
                  )),
                ],
              ),
            )).toList(),
          ),
        ],
      ),
    );
  }

  // ── Target Market Section ─────────────────────────────────────────────────────
  Widget _buildTargetMarketSection(BuildContext context) {
    final markets = [
      {'emoji': '💼', 'title': 'Working Professionals'},
      {'emoji': '👨‍👩‍👧', 'title': 'Nuclear Families'},
      {'emoji': '👴', 'title': 'Senior Citizens'},
      {'emoji': '👶', 'title': 'Parents'},
      {'emoji': '🐕', 'title': 'Pet Owners'},
      {'emoji': '🏙️', 'title': 'Urban Households'},
    ];

    return SectionPad(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionTag(text: 'Target Market'),
          const SizedBox(height: 8),
          const SectionHeading(text: 'Who We Serve'),
          const SizedBox(height: 24),
          Wrap(
            spacing: 12, runSpacing: 12,
            children: markets.map((m) => Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: HomivaTheme.cardBg,
                border: Border.all(color: HomivaTheme.borderColor),
                borderRadius: BorderRadius.circular(100),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(m['emoji']!, style: const TextStyle(fontSize: 16)),
                  const SizedBox(width: 8),
                  Text(m['title']!, style: GoogleFonts.dmSans(
                    fontSize: 13, fontWeight: FontWeight.w500, color: HomivaTheme.dark,
                  )),
                ],
              ),
            )).toList(),
          ),
        ],
      ),
    );
  }

  // ── Footer CTA ────────────────────────────────────────────────────────────────
  Widget _buildFooterCta(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 16, 20, 32),
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        color: HomivaTheme.coral,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [BoxShadow(color: HomivaTheme.coral.withOpacity(0.3), blurRadius: 24, offset: const Offset(0, 8))],
      ),
      child: Column(
        children: [
          Text('Ready to experience\ntrusted home care?',
            textAlign: TextAlign.center,
            style: GoogleFonts.dmSerifDisplay(fontSize: 24, color: Colors.white, height: 1.2)),
          const SizedBox(height: 8),
          Text('Join thousands of families who trust HOMIVA.',
            textAlign: TextAlign.center,
            style: GoogleFonts.dmSans(fontSize: 13, color: Colors.white70)),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text('Get Started Free',
              style: GoogleFonts.dmSans(fontSize: 14, fontWeight: FontWeight.w700, color: HomivaTheme.coral)),
          ),
        ],
      ),
    );
  }
}

// ── Service Card Widget ───────────────────────────────────────────────────────
class _ServiceCard extends StatelessWidget {
  final ServiceModel service;
  const _ServiceCard({required this.service});

  static const List<Color> _cardColors = [
    Color(0xFFFFF3F1), Color(0xFFF0F8FF), Color(0xFFF0FFF4), Color(0xFFFFFAF0),
  ];

  @override
  Widget build(BuildContext context) {
    final bgColor = _cardColors[service.colorIndex % _cardColors.length];
    return GestureDetector(
      onTap: () => Navigator.push(context,
        MaterialPageRoute(builder: (_) => ServiceDetailScreen(service: service))),
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: HomivaTheme.borderColor),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 52, height: 52,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)],
                  ),
                  child: Center(child: Text(service.emoji, style: const TextStyle(fontSize: 24))),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(service.title, style: GoogleFonts.dmSerifDisplay(
                        fontSize: 18, fontWeight: FontWeight.w600, color: HomivaTheme.dark,
                      )),
                      Text(service.subtitle, style: GoogleFonts.dmSans(
                        fontSize: 12, color: HomivaTheme.taupe,
                      )),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: HomivaTheme.coral,
                    borderRadius: BorderRadius.circular(100),
                  ),
                  child: Text('from ${service.avgPrice}',
                    style: GoogleFonts.dmSans(fontSize: 11, fontWeight: FontWeight.w700, color: Colors.white)),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Text(service.description,
              maxLines: 2, overflow: TextOverflow.ellipsis,
              style: GoogleFonts.dmSans(fontSize: 13, color: HomivaTheme.taupe, height: 1.6)),
            const SizedBox(height: 14),
            Wrap(
              spacing: 8, runSpacing: 8,
              children: service.tags.take(3).map((tag) => Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(color: HomivaTheme.borderColor),
                  borderRadius: BorderRadius.circular(100),
                ),
                child: Text(tag, style: GoogleFonts.dmSans(fontSize: 11, color: HomivaTheme.taupe)),
              )).toList(),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('View Details →', style: GoogleFonts.dmSans(
                  fontSize: 13, fontWeight: FontWeight.w600, color: HomivaTheme.coral,
                )),
                Text('Tap to explore', style: GoogleFonts.dmSans(fontSize: 11, color: HomivaTheme.muted)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
